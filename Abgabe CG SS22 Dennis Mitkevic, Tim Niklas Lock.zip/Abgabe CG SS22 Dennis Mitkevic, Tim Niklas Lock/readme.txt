Space Invaders
Authoren: Dennis Mitkevic, Tim Niklas Lock

Ziel des Spiels ist es alle Gegner abzuschießen, bevor diese den Boden erreichen.

Steuerung:
Enter = Spieltstart / Menüauswahl bestätigen
Pfeiltasten Links/Rechts = Steuern
Pfeiltasten Oben/Unten = Menüauswahl
Escape = Menü aufrufen
Spacebar = Schießen

Zum verständniss für das Postprocessing: https://www.youtube.com/watch?v=QQ3jr-9Rc1o
Es wurde jedoch kein Quelltext übernommen

Postprocessing shake-Effekt
https://learnopengl.com/In-Practice/2D-Game/Postprocessing