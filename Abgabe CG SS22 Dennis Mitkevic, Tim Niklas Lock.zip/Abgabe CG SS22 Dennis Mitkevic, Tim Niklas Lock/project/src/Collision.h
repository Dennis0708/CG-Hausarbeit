#pragma once
enum class Collision
{
	UP, DOWN, LEFT, RIGHT, NONE
};

