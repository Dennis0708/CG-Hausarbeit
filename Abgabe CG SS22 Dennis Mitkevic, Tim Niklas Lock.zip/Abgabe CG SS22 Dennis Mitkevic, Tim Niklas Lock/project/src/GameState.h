#pragma once
enum class GameState
{
    BEFORE_START, PAUSE, GAME_IS_ACTIVE, RESET, EXIT
};